package com.centec.myapplication;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.TextView;

public class MainActivity extends AppCompatActivity {
    TextView tvResultado;
    EditText edPeso;
    EditText edAltura;
    private String mensagem;
    private float peso;
    private float altura;
    private float imc;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        TextView tvResultado = findViewById(R.id.tvResultado);
        EditText edPeso = findViewById(R.id.edPeso);
        EditText edAltura = findViewById(R.id.edAltura);

    }
    public void btnCalcularonclick (View view){
        peso = Integer.parseInt(edPeso.getText().toString());
        altura = Integer.parseInt(edAltura.getText().toString());

        imc =peso / (altura * altura);

        if (imc < 18,5){
            mensagem = "Abaixo do peso normal";
        }else if ((imc>=18.5) && (imc<24.9)){
            mensagem = "peso normal";
        } else if ((imc>=25)&&(imc<29.9)) {
            mensagem = "Excesso de peso";
        }else if ((imc>=30)&&(imc<34.9)) {
            mensagem = "Obesidade classe I";
        }else if ((imc>=35)&&(imc<39.9)) {
            mensagem = "Obesidade classe II";
        }else if (imc>=40) {
            mensagem = "Obesidade classe III";
        }

    }
}